const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('path');
const fs = require('fs');

let mainWindow;
const dataPath = () => path.join(app.getPath('userData'), 'lc-management-data.json');

function initialData() {
  return {
    version: 1,
    settings: {
      nameBn: 'LC Import Management',
      nameEn: 'LC Import Management',
      email: '',
      phone: '',
      address: '',
      currency: 'BDT',
      logoPath: ''
    },
    cash: [],
    bank: [],
    expense: [],
    stock: [],
    stockAdjustments: []
  };
}

function readData() {
  const file = dataPath();
  try {
    if (!fs.existsSync(file)) {
      const fresh = initialData();
      fs.mkdirSync(path.dirname(file), { recursive: true });
      fs.writeFileSync(file, JSON.stringify(fresh, null, 2), 'utf8');
      return fresh;
    }
    const parsed = JSON.parse(fs.readFileSync(file, 'utf8'));
    const fresh = initialData();
    return { ...fresh, ...parsed, settings: { ...fresh.settings, ...(parsed.settings || {}) } };
  } catch (e) {
    throw new Error('ডেটা ফাইল পড়া যায়নি। ব্যাকআপ থাকলে সেটি পুনরুদ্ধার করুন। বিস্তারিত: ' + e.message);
  }
}

function writeData(data) {
  if (!data || typeof data !== 'object') throw new Error('ভুল ডেটা পাওয়া গেছে।');
  const file = dataPath();
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const temp = file + '.tmp';
  fs.writeFileSync(temp, JSON.stringify(data, null, 2), 'utf8');
  fs.renameSync(temp, file);
  return { ok: true };
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 980,
    minHeight: 650,
    title: 'LC Import & Wholesale Management',
    backgroundColor: '#f3f5fb',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });
  mainWindow.loadFile(path.join(__dirname, 'index.html'));
}

app.whenReady().then(() => {
  ipcMain.handle('data:load', () => readData());
  ipcMain.handle('data:save', (_event, data) => writeData(data));
  ipcMain.handle('backup:export', async (_event, data) => {
    const result = await dialog.showSaveDialog(mainWindow, {
      title: 'ব্যাকআপ সংরক্ষণ করুন',
      defaultPath: `lc-management-backup-${new Date().toISOString().slice(0,10)}.json`,
      filters: [{ name: 'JSON Backup', extensions: ['json'] }]
    });
    if (result.canceled || !result.filePath) return { canceled: true };
    fs.writeFileSync(result.filePath, JSON.stringify(data || readData(), null, 2), 'utf8');
    return { ok: true, filePath: result.filePath };
  });
  ipcMain.handle('backup:import', async () => {
    const result = await dialog.showOpenDialog(mainWindow, {
      title: 'ব্যাকআপ ফাইল নির্বাচন করুন',
      properties: ['openFile'],
      filters: [{ name: 'JSON Backup', extensions: ['json'] }]
    });
    if (result.canceled || !result.filePaths.length) return { canceled: true };
    const parsed = JSON.parse(fs.readFileSync(result.filePaths[0], 'utf8'));
    if (!parsed || !parsed.settings || !Array.isArray(parsed.cash) ||
        !Array.isArray(parsed.bank) || !Array.isArray(parsed.expense) ||
        !Array.isArray(parsed.stock)) {
      throw new Error('এই ফাইলটি LC Management-এর সঠিক ব্যাকআপ নয়।');
    }
    writeData(parsed);
    return { ok: true, data: readData() };
  });
  ipcMain.handle('export:csv', async (_event, { filename, csv }) => {
    const result = await dialog.showSaveDialog(mainWindow, {
      title: 'CSV রিপোর্ট সংরক্ষণ করুন',
      defaultPath: filename || 'report.csv',
      filters: [{ name: 'CSV', extensions: ['csv'] }]
    });
    if (result.canceled || !result.filePath) return { canceled: true };
    fs.writeFileSync(result.filePath, '\uFEFF' + csv, 'utf8');
    return { ok: true, filePath: result.filePath };
  });
  ipcMain.handle('company:logo', async () => {
    const result = await dialog.showOpenDialog(mainWindow, {
      title: 'কোম্পানির লোগো নির্বাচন করুন',
      properties: ['openFile'],
      filters: [{ name: 'Image', extensions: ['png', 'jpg', 'jpeg', 'webp'] }]
    });
    if (result.canceled || !result.filePaths.length) return { canceled: true };
    const source = result.filePaths[0];
    const ext = path.extname(source).toLowerCase();
    const dest = path.join(app.getPath('userData'), 'company-logo' + ext);
    fs.copyFileSync(source, dest);
    return { ok: true, path: dest };
  });
  ipcMain.handle('app:data-location', () => dataPath());
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});