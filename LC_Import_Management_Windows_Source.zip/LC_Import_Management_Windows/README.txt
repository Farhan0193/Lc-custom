LC IMPORT & WHOLESALE MANAGEMENT — WINDOWS সংস্করণ
===================================================

এই প্রকল্পের বৈশিষ্ট্য
--------------------
- সম্পূর্ণ বাংলা UI
- ক্যাশ বুক, ব্যাংক ও ক্যাশ, খরচ
- গোডাউন স্টক এবং স্টক সমন্বয়
- রিপোর্ট, স্টক মূল্যায়ন ও সারাংশ
- কোম্পানির বাংলা/ইংরেজি নাম, Gmail, ফোন, ঠিকানা ও লোগো নির্বাচন
- Print / Save as PDF
- CSV রিপোর্ট ডাউনলোড
- JSON ব্যাকআপ এবং ব্যাকআপ থেকে পুনরুদ্ধার
- এক কম্পিউটারে লোকাল ডেটা ফাইল; ইন্টারনেট ছাড়াই অ্যাপ চালানো যায়

A. Windows-এ ইনস্টলযোগ্য EXE তৈরি করার নিয়ম
-------------------------------------------
আপনার Windows কম্পিউটারে Node.js LTS ইনস্টল করুন:
https://nodejs.org/

তারপর:
1. এই ZIP Extract করুন।
2. Extract করা ফোল্ডার খুলুন।
3. ফোল্ডারের খালি জায়গায় Shift + Right-click করে "Open in Terminal" নির্বাচন করুন।
4. এই কমান্ড চালান:
   npm install
5. ডেভেলপমেন্ট মোডে পরীক্ষা করতে:
   npm start
6. Windows installer বানাতে:
   npm run dist
7. তৈরি হওয়া installer পাবেন:
   release/ ফোল্ডারের ভিতরে LC Import Management Setup 1.0.0.exe-এর মতো নামের ফাইল।

EXE এখানে আগে থেকে তৈরি করা নেই; Windows-এ উপরের build steps চালাতে হবে।
Electron build সাধারণত Windows-এ Windows installer তৈরি করতে সবচেয়ে নির্ভরযোগ্য।

B. ব্যবহার
----------
1. অ্যাপ খুলে "কোম্পানির সেটিংস"-এ যান।
2. কোম্পানির বাংলা/ইংরেজি নাম, Gmail, ফোন ও ঠিকানা দিন।
3. ক্যাশ বুক / ব্যাংক ও ক্যাশ / খরচ থেকে লেনদেন যোগ করুন।
4. গোডাউন স্টক থেকে পণ্যের নাম, কোড, পরিমাণ, একক, ক্রয়মূল্য ও বিক্রয়মূল্য দিন।
5. রিপোর্ট দেখতে "রিপোর্ট" খুলুন।
6. "প্রিন্ট / PDF" বাটনে ক্লিক করে Windows Print dialog থেকে "Microsoft Print to PDF" বা "Save as PDF" নির্বাচন করুন।
7. CSV বাটন থেকে বর্তমান তালিকার CSV রিপোর্ট সংরক্ষণ করুন।
8. নিয়মিত "ব্যাকআপ ডাউনলোড" করে JSON ফাইল আলাদা নিরাপদ জায়গায় রাখুন।
9. ডেটা ফেরত আনতে সেটিংস > ব্যাকআপ আপলোড / পুনরুদ্ধার ব্যবহার করুন।

C. ডেটা কোথায় থাকে?
-------------------
অ্যাপের ডেটা Electron-এর userData directory-তে lc-management-data.json নামে থাকে।
সাধারণত Windows-এ এটি AppData\Roaming-এর অ্যাপ-ডেটা ফোল্ডারের ভিতরে থাকবে।
সঠিক অবস্থান অ্যাপের Settings পৃষ্ঠায় দেখানো হয়।
অ্যাপ uninstall করলেও userData ফোল্ডার মুছে ফেলবেন না, যদি হিসাব রাখতে চান।

D. গুরুত্বপূর্ণ হিসাব-সংক্রান্ত সীমাবদ্ধতা
-----------------------------------------
- এটি একটি প্রাথমিক লোকাল ম্যানেজমেন্ট অ্যাপ; audited accounting/ERP-এর বিকল্প নয়।
- ক্যাশ, ব্যাংক এবং খরচ এন্ট্রি আলাদা তালিকায় রাখা হয়। সব পেমেন্টের জন্য একক double-entry ledger বা bank reconciliation এখনো নেই।
- বিক্রয়/ক্রয় invoice, customer/supplier ledger, VAT/tax, receivables/payables, multi-user login, encryption এবং automatic cloud sync অন্তর্ভুক্ত নয়।
- ডেটা হারানো ঠেকাতে প্রতিদিন JSON ব্যাকআপ নিন।
- বাস্তব ব্যবসায় ব্যবহার করার আগে কপি ডেটা দিয়ে সব ফর্ম, রিপোর্ট ও ব্যাকআপ পরীক্ষা করুন।

E. সোর্স কোড
------------
main.js       — Electron window, local JSON storage, file dialogs
preload.js    — নিরাপদ IPC bridge
index.html    — বাংলা UI structure
styles.css    — layout and print styling
renderer.js   — forms, reports, stock logic, CSV/backup UI
package.json  — dependencies and Windows installer build
