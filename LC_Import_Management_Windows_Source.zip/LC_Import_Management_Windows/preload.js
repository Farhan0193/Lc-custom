const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('lcApp', {
  loadData: () => ipcRenderer.invoke('data:load'),
  saveData: (data) => ipcRenderer.invoke('data:save', data),
  exportBackup: (data) => ipcRenderer.invoke('backup:export', data),
  importBackup: () => ipcRenderer.invoke('backup:import'),
  exportCsv: (payload) => ipcRenderer.invoke('export:csv', payload),
  chooseLogo: () => ipcRenderer.invoke('company:logo'),
  getDataLocation: () => ipcRenderer.invoke('app:data-location')
});