-- LC SaaS starter schema (Supabase / PostgreSQL)
-- IMPORTANT:
-- 1) Run in a NEW Supabase project for testing first.
-- 2) Do not use this as a production launch without security review and end-to-end tests.
-- 3) Never put service_role / secret keys in index.html or GitHub.
-- 4) This schema does NOT by itself implement payment verification or invite acceptance.
--    Those must be handled by a trusted Edge Function/backend.

create extension if not exists pgcrypto;

create type public.account_kind as enum ('personal','company');
create type public.member_role as enum ('owner','admin','employee');
create type public.subscription_kind as enum ('monthly','lifetime');
create type public.subscription_state as enum ('pending','active','expired','suspended','cancelled');

create table if not exists public.workspaces (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  kind public.account_kind not null default 'company',
  created_by uuid not null references auth.users(id) on delete restrict,
  created_at timestamptz not null default now()
);

create table if not exists public.profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  account_kind public.account_kind,
  workspace_id uuid references public.workspaces(id) on delete restrict,
  created_at timestamptz not null default now(),
  constraint profile_workspace_kind_check check (
    (account_kind = 'personal' and workspace_id is null) or
    (account_kind = 'company' and workspace_id is not null) or
    account_kind is null
  )
);

create table if not exists public.workspace_members (
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role public.member_role not null default 'employee',
  active boolean not null default false,
  created_at timestamptz not null default now(),
  primary key (workspace_id,user_id)
);

create table if not exists public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  workspace_id uuid references public.workspaces(id) on delete cascade,
  plan public.subscription_kind not null,
  status public.subscription_state not null default 'pending',
  starts_at timestamptz,
  ends_at timestamptz,
  payment_reference text,
  approved_by uuid references auth.users(id) on delete set null,
  approved_at timestamptz,
  created_at timestamptz not null default now(),
  constraint subscription_owner_scope check (
    (workspace_id is null) or (workspace_id is not null)
  ),
  constraint lifetime_no_end_date check (plan <> 'lifetime' or ends_at is null)
);

create table if not exists public.access_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  requested_plan public.subscription_kind not null,
  workspace_name text,
  status public.subscription_state not null default 'pending',
  payment_note text,
  created_at timestamptz not null default now()
);

create table if not exists public.workspace_invites (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  email text not null,
  role public.member_role not null default 'employee',
  invited_by uuid not null references auth.users(id) on delete restrict,
  status text not null default 'pending' check (status in ('pending','accepted','revoked')),
  expires_at timestamptz not null default (now() + interval '7 days'),
  created_at timestamptz not null default now(),
  unique (workspace_id,email)
);

-- Accounting/business data tables. Every row is tenant-scoped.
create table if not exists public.cash_transactions (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid references public.workspaces(id) on delete cascade,
  owner_id uuid not null references auth.users(id) on delete cascade,
  date date not null,
  type text not null check(type in ('in','out')),
  note text not null,
  amount numeric(14,2) not null check(amount > 0),
  created_at timestamptz not null default now()
);
create table if not exists public.bank_transactions (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid references public.workspaces(id) on delete cascade,
  owner_id uuid not null references auth.users(id) on delete cascade,
  account_name text not null,
  date date not null,
  type text not null check(type in ('in','out')),
  note text not null,
  amount numeric(14,2) not null check(amount > 0),
  created_at timestamptz not null default now()
);
create table if not exists public.expenses (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid references public.workspaces(id) on delete cascade,
  owner_id uuid not null references auth.users(id) on delete cascade,
  date date not null,
  category text not null,
  note text not null,
  amount numeric(14,2) not null check(amount > 0),
  created_at timestamptz not null default now()
);
create table if not exists public.stock_items (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid references public.workspaces(id) on delete cascade,
  owner_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  code text not null,
  qty numeric(14,3) not null default 0 check(qty >= 0),
  unit text not null,
  cost numeric(14,2) not null default 0 check(cost >= 0),
  sale numeric(14,2) not null default 0 check(sale >= 0),
  created_at timestamptz not null default now()
);
create table if not exists public.lc_records (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid references public.workspaces(id) on delete cascade,
  owner_id uuid not null references auth.users(id) on delete cascade,
  lc_no text not null,
  supplier text not null,
  bank_name text not null,
  amount numeric(14,2) not null default 0 check(amount >= 0),
  status text not null default 'Open',
  created_at timestamptz not null default now()
);

-- Creator identity is controlled in SQL by you, not by a public signup form.
create table if not exists public.platform_owners (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);
alter table public.platform_owners enable row level security;
-- No public insert/update/delete policies intentionally.
create policy "platform owner can read own owner flag"
on public.platform_owners for select to authenticated
using (user_id = auth.uid());

create or replace function public.is_platform_owner()
returns boolean language sql stable security definer
set search_path = public
as $$
  select exists(select 1 from public.platform_owners po where po.user_id = auth.uid());
$$;

create or replace function public.is_workspace_member(wid uuid)
returns boolean language sql stable security definer
set search_path = public
as $$
  select exists (
    select 1 from public.workspace_members m
    where m.workspace_id = wid and m.user_id = auth.uid() and m.active = true
  );
$$;

create or replace function public.is_workspace_admin(wid uuid)
returns boolean language sql stable security definer
set search_path = public
as $$
  select exists (
    select 1 from public.workspace_members m
    where m.workspace_id = wid and m.user_id = auth.uid()
      and m.active = true and m.role in ('owner','admin')
  );
$$;

-- Do not let users self-promote by updating their role/account type/workspace.
alter table public.workspaces enable row level security;
alter table public.profiles enable row level security;
alter table public.workspace_members enable row level security;
alter table public.subscriptions enable row level security;
alter table public.access_requests enable row level security;
alter table public.workspace_invites enable row level security;

create policy "profiles read own" on public.profiles
for select to authenticated using (user_id = auth.uid() or public.is_platform_owner());
-- No client insert/update/delete policies on profiles: use a trusted backend/Edge Function.
create policy "workspaces read members or creator" on public.workspaces
for select to authenticated using (created_by = auth.uid() or public.is_workspace_member(id) or public.is_platform_owner());
-- Workspace creation and membership changes should be performed by trusted backend/Edge Function.
create policy "members read same workspace" on public.workspace_members
for select to authenticated using (user_id = auth.uid() or public.is_workspace_admin(workspace_id) or public.is_platform_owner());
-- No client insert/update/delete policies on membership.
create policy "subscription read own or platform owner" on public.subscriptions
for select to authenticated using (user_id = auth.uid() or public.is_platform_owner());
-- No client policy to activate subscriptions or mark payments as paid.
create policy "request create own" on public.access_requests
for insert to authenticated with check (user_id = auth.uid());
create policy "request read own or platform owner" on public.access_requests
for select to authenticated using (user_id = auth.uid() or public.is_platform_owner());
create policy "request owner update" on public.access_requests
for update to authenticated using (public.is_platform_owner()) with check (public.is_platform_owner());
create policy "invites read admins or invitee not exposed" on public.workspace_invites
for select to authenticated using (public.is_workspace_admin(workspace_id) or public.is_platform_owner());
-- Invite creation/acceptance/revocation must be backend-mediated.

-- RLS policies for data. Personal data: workspace_id IS NULL and owner_id=auth.uid().
-- Company data: active workspace membership, with workspace-scoped access.
do $$
declare t text;
begin
  foreach t in array array['cash_transactions','bank_transactions','expenses','stock_items','lc_records']
  loop
    execute format('alter table public.%I enable row level security', t);
    execute format(
      'create policy "tenant select" on public.%I for select to authenticated using ((workspace_id is null and owner_id = auth.uid()) or (workspace_id is not null and public.is_workspace_member(workspace_id)) or public.is_platform_owner())',
      t);
    execute format(
      'create policy "tenant insert" on public.%I for insert to authenticated with check ((workspace_id is null and owner_id = auth.uid()) or (workspace_id is not null and owner_id = auth.uid() and public.is_workspace_member(workspace_id)))',
      t);
    execute format(
      'create policy "tenant update" on public.%I for update to authenticated using ((workspace_id is null and owner_id = auth.uid()) or (workspace_id is not null and public.is_workspace_member(workspace_id))) with check ((workspace_id is null and owner_id = auth.uid()) or (workspace_id is not null and owner_id = auth.uid() and public.is_workspace_member(workspace_id)))',
      t);
    execute format(
      'create policy "tenant delete" on public.%I for delete to authenticated using ((workspace_id is null and owner_id = auth.uid()) or (workspace_id is not null and public.is_workspace_member(workspace_id)))',
      t);
  end loop;
end $$;

-- IMPORTANT BOOTSTRAP:
-- After you create and verify your own account in Supabase Authentication > Users,
-- copy YOUR auth user UUID and run this separately in SQL Editor:
-- insert into public.platform_owners(user_id) values ('YOUR-USER-UUID-HERE');
-- Never allow a public signup page to insert into platform_owners.
