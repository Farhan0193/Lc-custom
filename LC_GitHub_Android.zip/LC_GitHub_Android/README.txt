LC Import & Wholesale Management — Android/GitHub Pages

GitHub Pages-এ প্রকাশ:
1. GitHub.com-এ sign in করুন এবং New repository তৈরি করুন (যেমন lc-management)।
2. Add file > Upload files দিয়ে index.html আপলোড করুন।
3. Commit changes চাপুন।
4. Repository Settings > Pages খুলুন।
5. Build and deployment: Deploy from a branch নির্বাচন করুন।
6. Branch: main এবং folder: /(root) দিয়ে Save করুন।
7. Pages-এ দেখানো ওয়েবসাইট লিংক Android Chrome-এ খুলুন।

বৈশিষ্ট্য: বাংলা ক্যাশ বুক, ব্যাংক, খরচ, গোডাউন স্টক, অটো স্টক ক্যালকুলেশন, রিপোর্ট, কোম্পানি সেটিংস, Print/Save as PDF, JSON backup/restore এবং CSV download।

সতর্কতা:
- ডেটা একই ব্রাউজারের Local Storage-এ থাকে; অন্য ফোন/কম্পিউটারে sync হয় না।
- ব্রাউজারের ডেটা clear করলে হিসাব হারাতে পারেন; নিয়মিত JSON backup নিন।
- GitHub Pages public হতে পারে। বাস্তব/গোপন হিসাব এখানে দেবেন না।
- এটি প্রাথমিক demo, পূর্ণাঙ্গ double-entry accounting system নয়।
